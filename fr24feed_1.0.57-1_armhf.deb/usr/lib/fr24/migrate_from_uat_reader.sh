#!/bin/bash

UAT_READER_ACTIVE="$(systemctl is-active uat_reader.service)"
UAT_READER_ENABLED="$(systemctl is-enabled uat_reader.service)"

OLD_CONFIG="/etc/uat_reader/uat_reader.conf"
NEW_CONFIG="/etc/fr24uat-feed.ini"

if [ -e "${OLD_CONFIG}" ] && [ ! -s ${NEW_CONFIG} ]; then
    echo "Migrating config file from uat_reader to fr24uat-feed..."

    grep "fr24key=" ${OLD_CONFIG} > ${NEW_CONFIG}
    echo "receiver=uat-tcp" >> ${NEW_CONFIG}
    echo "uat-port=30978" >> ${NEW_CONFIG}

    chown fr24:fr24 ${NEW_CONFIG}
fi

if [ "${UAT_READER_ACTIVE}" == "active" ]; then
    echo "Terminating uat_reader"
    systemctl stop uat_reader.service
fi

if [ "${UAT_READER_ENABLED}" == "enabled" ]; then
    echo "Disabling uat_reader"
    systemctl disable uat_reader.service
fi

if [ -s /etc/fr24uat-feed.ini ]; then
    touch /dev/shm/uat-decoder.txt
    chown fr24:fr24 /dev/shm/uat-decoder.txt
fi