#!/bin/bash

rm -f /tmp/fr24feed_diagnostics.tgz

CURRENT_DIR=$(pwd)
TMP_DIR=$(mktemp -d)

cd "${TMP_DIR}" || exit 255

journalctl --since "24 hours ago" -u fr24feed > fr24feed.24h.log || true
journalctl --since "24 hours ago" -u fr24uat-feed > fr24uat-feed.24h.log || true

cp /etc/default/dump1090-mutability . || true

fr24feed --version > fr24feed_version.txt || true

grep -v fr24key /dev/shm/decoder.txt > decoder.txt || true
grep -v fr24key /dev/shm/uat-decoder.txt > uat-decoder.txt || true

ls -al /run/fr24feed /dev/shm/decoder.txt /dev/shm/uat-decoder.txt /run/dump1090-mutability /usr/lib/fr24 "$(which ping)" > dir_lists.txt || true

grep -v fr24key /etc/fr24feed.ini > fr24feed.ini || true
grep -v fr24key /etc/fr24uat-feed.ini > fr24uat-feed.ini || true
cp /etc/dump978-fr24/dump978-fr24.ini dump978-fr24.ini || true

# shellcheck disable=SC2009
ps aufx | grep -e fr24 -e dump1090 > processes.txt || true

systemctl status fr24feed >> fr24feed_status.txt
systemctl status fr24uat-feed >> fr24uat-feed_status.txt

/usr/lib/fr24/dump1090 --help 2>&1 | grep dump1090 > dump1090_version.txt || true

cp /var/log/apt/history.log apt_history.log || true

lsusb > lsusb.txt || true

uname -a > uname.txt || true

cp /etc/*release* /etc/*version* . || true

cp /var/log/syslog* /var/log/messages* . || true

getcap /usr/bin/fr24feed > fr24feed_cap.txt || true

netstat -tna > netstat.txt || true

ip a > network.txt || true

cat /usr/lib/fr24/image_version.txt > image_version.txt || true

for pid in $(pgrep fr24feed); do
    lsof -nPp "$pid" > "fr24feed_lsof.${pid}.txt" || true
    ls -al "/proc/$pid/fd" > "fr24feed_fd.${pid}.txt" || true
done

free -h > free.txt
uptime > uptime.txt

tar -czf /tmp/fr24feed_diagnostics.tgz .
chmod a+rw /tmp/fr24feed_diagnostics.tgz

cd "${CURRENT_DIR}" && rm -fr "${TMP_DIR}"

echo "Diagnostics dumped into an archive /tmp/fr24feed_diagnostics.tgz"
echo "Please send this file to Flightradar24 support if you want assistance with your feed."

exit 0

