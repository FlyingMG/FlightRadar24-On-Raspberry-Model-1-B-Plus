#!/bin/bash

function iw_parser() {
    local first name signal line

    first=true
    name=""
    signal=""

    echo -n "["

    while read -r line; do
        if [[ -z "${line//'SSID: '*}" ]] ; then
            name="${line/'SSID: '}"
        fi
        
        if [[ -z "${line//'signal: '*}" ]] ; then
            signal="${line/'signal: '}"
        fi

        if [ -n "${name}" ] && [ -n "${signal}" ] ; then
            if [ "${first}" = true ] ; then
                first=false
            else
                echo -n ","
            fi

            echo -n "{\"name\":\"${name}\",\"signal\":\"${signal}\"}"

            name=""
            signal=""
        fi
    done

    echo "]"
}

sudo ifconfig wlan0 up

iw_parser <<< "$(timeout 15s bash -c 'until sudo iw wlan0 scan; do sleep 1; done')"